#!/usr/bin/env python

# Copyright (c) 2011, Willow Garage, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#    * Neither the name of the Willow Garage, Inc. nor the names of its
#      contributors may be used to endorse or promote products derived from
#       this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

import roslib
import rospy
import tf.transformations
from geometry_msgs.msg import Twist, PolygonStamped
import socket
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from visualization_msgs.msg import Marker 
from visualization_msgs.msg import MarkerArray 
from geometry_msgs.msg import Point 
import time
import numpy as np
import math
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion, quaternion_from_euler

x = 0.0
y = 0.0
theta = 0.0
err = 0.065

topic = 'visualization_marker_array' 
publisher = rospy.Publisher(topic, MarkerArray, queue_size=5)
markerArray = MarkerArray()
count = 0

Ip = "192.168.43.197"
port = 20001
UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
UDPServerSocket.bind((Ip, port))
data_,addr_ = UDPServerSocket.recvfrom(1024)  #Communication from MR_server file
print(data_.decode('utf-8'))
UDPServerSocket.sendto("Hi Server".encode('utf-8'),addr_)

data,addr = UDPServerSocket.recvfrom(1024)  #Communication from Dobot
print(data.decode('utf-8'))
UDPServerSocket.sendto("Hi Client".encode('utf-8'),addr)


def move():
    # Starts a new node
    #rospy.init_node('more_dist', anonymous=True)
    velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    vel_msg = Twist()
    #print("Moved into the workspace")
    distance = 0.18#0.11
    speed = 0.2
    vel_msg.linear.x = 0.2
    vel_msg.linear.y = 0
    vel_msg.linear.z = 0
    vel_msg.angular.x = 0
    vel_msg.angular.y = 0
    vel_msg.angular.z = 0
    t0 = rospy.Time.now().to_sec()
    current_distance = 0
    while(current_distance < distance):
    	velocity_publisher.publish(vel_msg)
    	t1=rospy.Time.now().to_sec()
    	current_distance= speed*(t1-t0)
    	#print(current_distance)
    	time.sleep(0.1)
    vel_msg.linear.x = 0
    print("Done")
    velocity_publisher.publish(vel_msg)

def newOdom (msg):
    global x
    global y
    #p = PolygonStamped()
    x0 = msg.polygon.points[0].x
    y0 = msg.polygon.points[0].y
    x1 = msg.polygon.points[1].x
    y1 = msg.polygon.points[1].y
    x2 = msg.polygon.points[2].x
    y2 = msg.polygon.points[2].y
    x3 = msg.polygon.points[3].x
    y3 = msg.polygon.points[3].y

    v = [ [ x0, y0],
    [ x1, y1],
    [ x2, y2 ],
    [x3, y3] ]

    ans = [0, 0]

    n = len(v)
    signedArea = 0

    # For all vertices
    for i in range(len(v)):

        x0 = v[i][0]
        y0 = v[i][1]
        x1 = v[(i + 1) % n][0]
        y1 =v[(i + 1) % n][1]

        # Calculate value of A
        # using shoelace formula
        A = (x0 * y1) - (x1 * y0)
        signedArea += A

        # Calculating coordinates of
        # centroid of polygon
        ans[0] += (x0 + x1) * A
        ans[1] += (y0 + y1) * A

    signedArea *= 0.5
    x = (ans[0]) / (6 * signedArea)
    y = (ans[1]) / (6 * signedArea)
    #print(x,y)
    return

def movebase_client(x_,y_,th_):
	global client
	client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
	client.wait_for_server()

	goal = MoveBaseGoal()
	goal.target_pose.header.frame_id = "map"
	goal.target_pose.header.stamp = rospy.Time.now()
	goal.target_pose.pose.position.x = x_
	goal.target_pose.pose.position.y = y_
	q = quaternion_from_euler(0, 0, th_)
	goal.target_pose.pose.orientation.x = q[0]
	goal.target_pose.pose.orientation.y = q[1]
	goal.target_pose.pose.orientation.z = q[2]
	goal.target_pose.pose.orientation.w = q[3]
	print(q)
	# goal.target_pose.pose.orientation.z = th_
	# goal.target_pose.pose.orientation.w = 1.0

	client.send_goal(goal)
	    # wait = client.wait_for_result()
	    # if not wait:
	    #     rospy.logerr("not available")
	    #     rospy.signal_shutdown("not available")
	    # else:
	    #     return client.get_result()

def move_to(x,y,th):
	result = movebase_client(x,y,th)
	#try:
		# rospy.init_node('movebase_client')
		# global UDPServerSocket
		# print("Here")
		# data,addr = UDPServerSocket.recvfrom(1024)
		# print("Here")
		# print(data.decode('utf-8'))
		# A = str(x)+" "+str(y)
		# message = A.encode('utf-8')
		# UDPServerSocket.sendto(message, addr)
		#result = movebase_client(x,y,th)
		#if result:
			#move = Twist()
			#rospy.loginfo("Goal execution done!")
			
			#UDPServerSocket.bind((Ip, port))
			# data,addr = UDPServerSocket.recvfrom(1024)
			# print(data.decode('utf-8'))
			# message = "Pick the object".encode('utf-8')
			# UDPServerSocket.sendto(message, addr)
			#exit()
		#else:
			#msg = "Fail"
			# UDPServerSocket.bind((Ip, port))
			# data,addr = UDPServerSocket.recvfrom(1024)
			# print(data.decode('utf-8'))
			# message = msg.encode('utf-8')
			# UDPServerSocket.sendto(message, addr)
			#exit()
	#except rospy.ROSInterruptException:
		#rospy.loginfo("Navigation done")



def Set_Vel(vx,vw):
	twist = Twist()
	twist.linear.y = 0.0; twist.linear.z = 0.0
	twist.angular.x = 0.0; twist.angular.y = 0.0;
	twist.linear.x = vx
	twist.angular.z = vw

	velocity_publisher.publish(twist)
	time.sleep(0.1)

def getK():
	with open("Auto.txt","r") as f:
		cmd = f.read()
		print(cmd)
	return cmd

rospy.init_node('AutoUI');
velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

with open('current_flag.txt','w') as cur:
	cur.write('0')

sub = rospy.Subscriber('/move_base/global_costmap/footprint', PolygonStamped, newOdom)

db_X = -3.16 #-2.65 #-2.69 #6.17 #2.5 
db_Y = -1.41 #-1.15 #-1.08 #-1.53 #-1.22 #-0.81 
db_th = -1*math.pi/2

#db_X = 0
#db_Y = 0
#db_th = 0


l = np.arange(-90,90,3)
l = np.append(l,90)
xl = np.zeros(len(l))
yl = np.zeros(len(l))

for i in range(0,len(l)):
	xl[i] = db_X+0.45*(math.cos(db_th+(math.pi*l[i]/180)))
	yl[i] = db_Y+0.45*(math.sin(db_th+(math.pi*l[i]/180)))
	marker = Marker()
	marker.id = count
	marker.lifetime = rospy.Duration()
	marker.header.frame_id = "map"
	marker.type = marker.SPHERE
	marker.action = marker.ADD
	marker.scale.x = 0.03
	marker.scale.y = 0.03
	marker.scale.z = 0.03
	marker.color.a = 1.0
	marker.color.r = 0.0
	marker.color.g = 1.0
	marker.color.b = 0.0
	marker.pose.orientation.w = 1.0
	marker.pose.position.x = xl[i] 
	marker.pose.position.y = yl[i] 
	marker.pose.position.z = 0 
	markerArray.markers.append(marker) 
	count += 1
	#print(xl[i],yl[i],"were probable points")
print("waiting 2 seconds before displaying markers")
rospy.sleep(2)
publisher.publish(markerArray)

dist = np.zeros(len(l))
current_dist = 0


while not rospy.is_shutdown():
	check = '0'
	with open('current_flag.txt','r') as flag:
		check = flag.read()

	if check == '1':
		while True:
			print("current position is: ",x, y)
			for i in range(len(l)):
				dist[i] = math.sqrt(pow(xl[i]-x,2)+pow(yl[i]-y,2))
				#dist[i] = math.sqrt(pow((xl[i]+0.25)-(x+0.25),2)+pow((yl[i]+0.65)-(y+0.65),2))
			#print(dist)
			ind = np.argmin(dist)
			xg = xl[ind]
			#print("Xg is: ",xg)
			yg = yl[ind]
			#print("Yg is: ")
			xg_ = xg*math.cos(err) + yg*math.sin(err)
			yg_ = yg*math.cos(err) - xg*math.sin(err)
			#print("New goal Xg is: ", xg_)
			#print("New goal Yg is: ", yg_)

			# UDPServerSocket.sendto(str(l[ind]).encode('utf-8'),addr)

			if xg-db_X > 0:
				print("greater than 0")
				thg = math.atan2(yg-(db_Y),xg-(db_X)) + math.pi
			else:
				print("Less than zero")
				thg = math.atan2(yg-(db_Y),xg-(db_X)) - math.pi
			# if yg-db_Y>0:
			# 	thg = math.atan2(yg-(db_Y),xg-(db_X)) - math.pi
			# else:
			# 	thg = math.atan2(yg-(db_Y),xg-(db_X))
			print(xg,yg,thg,"was goal position")
			move_to(xg,yg,thg)
			current_dist = math.sqrt(pow(db_X-x,2)+pow(db_Y-y,2))
			print("distance from dobot: ", current_dist)
			if current_dist < 0.6:
				wait = client.wait_for_result()
				if not wait:
					rospy.logerr("not available")
					rospy.signal_shutdown("not available")
				print("Exiting loop")
				break

			time.sleep(3)
			#rospy.spin()
		print("x and y is:", x, y)	
		print("moving straight")
		move()
		UDPServerSocket.sendto("Pick".encode('utf-8'),addr)
		print("Exiting Autonmous Pick Place")
		with open('current_flag.txt','w') as flag:
			flag.write('0')
		continue
	else:
			cmd = getK()
			if cmd=='6':
				vel_x = 0.0
				vel_om = 0.0

			elif cmd=='2':
				vel_x = 0.1
				vel_om = 0.0

			elif cmd=='3':
				vel_x = 0.0
				vel_om = 0.4

			elif cmd=='4':
				vel_x = 0.0
				vel_om = -0.4

			elif cmd=='5':
				vel_x = -0.1
				vel_om = 0.0

			Set_Vel(vel_x,vel_om)

